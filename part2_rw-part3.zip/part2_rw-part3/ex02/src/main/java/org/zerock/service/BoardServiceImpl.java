package org.zerock.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.zerock.domain.BoardVO;
import org.zerock.mapper.BoardMapper;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@Service
@AllArgsConstructor
public class BoardServiceImpl implements BoardService{
	
	//mapper 관련 오류가 떠서 이것을 넣어서 오류를 우선적으로 해결을 하였다.
	private BoardMapper mapper;

	//Spring 4.3이상에서 자동 처리
	@Override
	public void register(BoardVO board) {
		log.info("register....." + board);
		
		mapper.insertSelectKey(board);
	}

	@Override
	public BoardVO get(Long bno) {
		// TODO Auto-generated method stub
		return null;
	}

	//수정
	@Override
	public boolean modify(BoardVO board) {
		// TODO Auto-generated method stub
		log.info("modify........" + board);
		
		return mapper.update(board)==1;
	}

	//삭제
	@Override
	public boolean remove(Long bno) {
		// TODO Auto-generated method stub
		
		log.info("remove......" + bno);
		return mapper.delete(bno)==2;
	}

	@Override
	public List<BoardVO> getList() {
		// TODO Auto-generated method stub
		
		log.info("getList..........");
		return mapper.getList();
	}
	
	//삭제 수정 true false로 표현하기
	

}
