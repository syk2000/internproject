package org.zerock.controller;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application home page.
 */
//servlet-context.xml의 component-scan에읽혀 bean으로 등록
@Controller
public class HomeController {

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	// annotation-driven이 이부분을 읽어 /을 처리할 수있는 controller
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		// 계속 보드에 나오지가 않아서 수정을 새로 해주었습니다.
		/* logger.info(list+":"+Criteria(pageNum=1, amount=10),locale); */
		/* logger.info(list+":"+Criteria(pageNum=1, amount=j),locale); */
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);

		String formattedDate = dateFormat.format(date);

		model.addAttribute("serverTime", formattedDate);

		return "board/list";
	}

	/*
	 * private Object Criteria(int i, int j) { // TODO Auto-generated method stub
	 * i=1; j=10; return i; }
	 */

}
