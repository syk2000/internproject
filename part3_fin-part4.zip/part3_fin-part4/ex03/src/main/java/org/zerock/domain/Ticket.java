package org.zerock.domain;

import lombok.Data;

@Data
public class Ticket {
	private int tno;
	private String owner;
	private String grade;
	public void setTno(int tno2) {
		// TODO Auto-generated method stub
		
	}
}
