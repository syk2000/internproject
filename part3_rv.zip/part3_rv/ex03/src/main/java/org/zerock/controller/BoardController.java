package org.zerock.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.zerock.domain.BoardVO;
import org.zerock.domain.Criteria;
import org.zerock.domain.PageDTO;
import org.zerock.service.BoardService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@RequestMapping("/board/*")
@AllArgsConstructor
public class BoardController {

	private BoardService service; //DI 보더 서비스를 주입 autowired 자동 생략

	@GetMapping("/register")
	public void register() {

	}


	// @GetMapping("/list")
	// public void list(Criteria cri, Model model) {
	//
	// log.info("list: " + cri);
	// model.addAttribute("list", service.getList(cri));
	//
	// }
	
	//조회 기능을 하는 것으로 알면 될 것 같다.
	@GetMapping("/list")
	public void list(Criteria cri, Model model) {
		log.info("list: " + cri);
		model.addAttribute("list: "+ cri);
		model.addAttribute("list", service.getList(cri));
		model.addAttribute("pageMaker", new PageDTO(cri,123));
		
		//아래 3개 줄의 코딩을 사용하여 기술을 적용하고 싶으면 Criteria.java에 typeArr이라는 기능을 적용해야 작동이 된다.
		  int total = service.getTotal(cri);
		  
		  log.info("total:" + total);
		  
		  model.addAttribute("pageMaker" , new PageDTO(cri, total));
		 
	}

	

	@PostMapping("/register")
	public String register(BoardVO board, RedirectAttributes rttr) {

		log.info("register: " + board);//웹서버에서 주로 이용한다.
		//debug.~~ = 주로 로컬에서 사용을 한다.

		service.register(board);

		rttr.addFlashAttribute("result", board.getBno());

		return "redirect:/board/list";
	}

	// @GetMapping({ "/get", "/modify" })
	// public void get(@RequestParam("bno") Long bno, Model model) {
	//
	// log.info("/get or modify ");
	// model.addAttribute("board", service.get(bno));
	// }
	
	//게시판에 해당 글제목으로 들어갈때 사용하는 기능이다.
	@GetMapping({"/get", "/modify"})
	public void get (@RequestParam("bno") Long bno, @ModelAttribute("cri") Criteria cri, Model model) {
		
		log.info("/get or modify");
		model.addAttribute("board",service.get(bno));
	} 

	//글 정보를 보고 수정하기 버튼 눌렀을 때
	@PostMapping("/modofy")
	public String modify(BoardVO board, @ModelAttribute("cri") Criteria cri, RedirectAttributes rttr) {
		log.info("modify:" + board);
		
		if(service.modify(board)) {
			rttr.addFlashAttribute("result","success");
		}
		
		/*
		 * rttr.addAttribute("pageNum", cri.getPageNum()); rttr.addAttribute("amount",
		 * cri.getAmount()); rttr.addAttribute("type",cri.getType());
		 * rttr.addAttribute("keyword",cri.getKeyword());
		 */
		//cri.getListLink()를 사용함으로서 위 3줄을 생략을 하였다.
		
		return "redirect:/board/list" + cri.getListLink();
	}
	// @PostMapping("/modify")
	// public String modify(BoardVO board, RedirectAttributes rttr) {
	// log.info("modify:" + board);
	//
	// if (service.modify(board)) {
	// rttr.addFlashAttribute("result", "success");
	// }
	// return "redirect:/board/list";
	// }

	/*
	 * @PostMapping("/modify") public String modify(BoardVO
	 * board, @ModelAttribute("cri") Criteria cri, RedirectAttributes rttr) {
	 * log.info("modify:" + board);
	 * 
	 * if (service.modify(board)) { rttr.addFlashAttribute("result", "success"); }
	 * 
	 * rttr.addAttribute("pageNum", cri.getPageNum()); rttr.addAttribute("amount",
	 * cri.getAmount()); //rttr.addAttribute("type", cri.getType());
	 * //rttr.addAttribute("keyword", cri.getKeyword());
	 * 
	 * return "redirect:/board/list"; }
	 */

	// @PostMapping("/remove")
	// public String remove(@RequestParam("bno") Long bno, RedirectAttributes rttr)
	// {
	//
	// log.info("remove..." + bno);
	// if (service.remove(bno)) {
	// rttr.addFlashAttribute("result", "success");
	// }
	// return "redirect:/board/list";
	// }

	//삭제하기 버튼을 눌렀을 때
	@PostMapping("/remove")
	public String remove(@RequestParam("bno") Long bno, @ModelAttribute("cri") Criteria cri, RedirectAttributes rttr) {
		
		log.info("remove..." + bno);
		if(service.remove(bno)) {
			rttr.addFlashAttribute("result","successs");
		}
		
		/*
		 * rttr.addAttribute("pageNum", cri.getPageNum()); rttr.addAttribute("amount",
		 * cri.getAmount()); rttr.addAttribute("type",cri.getType());
		 * rttr.addAttribute("keyword", cri.getKeyword());
		 */
		
		return "redirect:/board/list" + cri.getListLink();
	}
	
	/*
	 * @PostMapping("/remove") public String remove(@RequestParam("bno") Long bno,
	 * Criteria cri, RedirectAttributes rttr) {
	 * 
	 * log.info("remove..." + bno); if (service.remove(bno)) {
	 * rttr.addFlashAttribute("result", "success"); } rttr.addAttribute("pageNum",
	 * cri.getPageNum()); rttr.addAttribute("amount", cri.getAmount()); //
	 * rttr.addAttribute("type", cri.getType()); // rttr.addAttribute("keyword",
	 * cri.getKeyword());
	 * 
	 * return "redirect:/board/list"; }
	 */
}
