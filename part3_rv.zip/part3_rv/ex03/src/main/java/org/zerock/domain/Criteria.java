package org.zerock.domain;

import org.springframework.web.util.UriComponentsBuilder;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@ToString
@Setter
@Getter
public class Criteria {

	private int pageNum;
	private int amount;
	
	private String type; 
	private String keyword;
	
	public Criteria() {
		this(1,10);
	}
					//페이지 수 하나당 amount의 값을 지정해준 생성자를 밑에 생성자로 불러 주었다.
	public Criteria(int pageNum, int amount) {
		this.pageNum = pageNum;
		this.amount = amount;
	}
	
	//페이지 324페이지를 하면 오류가 난다 그럴때 이것을 사용해야 오류가 나지 않는다는 것을 알 수가 있다. 500번에러 TypeArr을 사용해야 한다고 나온다.
	public String[] getTypeArr() {
		  
		  return type == null? new String[] {}: type.split("");
		  }
	
	public String getListLink() {
		
		UriComponentsBuilder builder = UriComponentsBuilder.fromPath("")
				.queryParam("pageNum", this.pageNum)
				.queryParam("amount", this.getAmount())
				.queryParam("type", this.getType())
				.queryParam("keyword", this.getKeyword());
				
			return builder.toUriString();
	}
}
