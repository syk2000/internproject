package org.zerock.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.zerock.domain.SampleVO;
import org.zerock.domain.Ticket;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/sample")
@Slf4j
public class SampleController {
	
	//단순 문자열 반환
	@GetMapping(value = "/getText" , produces = "text/plain charset=UTF-8")
	public String getText() {
		log.info("MIME TYPE: " + MediaType.TEXT_PLAIN_VALUE);
		
		return "안녕하세요";
	}
	
	//SampleVO를 린턴하는 메소드
	@GetMapping(value = "/getSample",
			produces = { MediaType.APPLICATION_ATOM_XML_VALUE,
					MediaType.APPLICATION_ATOM_XML_VALUE})
	
	public SampleVO getSample() {
		
		return new SampleVO(112, "스타", "로드");
	}
	
	@GetMapping(value = "/getSample2")
	public SampleVO getSample2() {
		return new SampleVO(113, "로켓", "라쿤");
	}
	
	//컬렉션 타입의 객체로 여러 데이터를 한번에 전송하기 위해서 배열이나 리스트, 맵 타입의 객체를 전송하는 경우입니다.
	@GetMapping(value = "/getList")
	public List<SampleVO> getList(){
		
		return IntStream.range(1, 10).mapToObj(i-> new SampleVO(i, i+ "First", i + "Last"))
				.collect(Collectors.toList());
	}
	
	//키와 값을 가지는 하나의 객체로 간주가 된다.
	@GetMapping(value = "/getMap")
	public Map<String, SampleVO> getMap(){
		
		Map<String, SampleVO> map = new HashMap<>();
		map.put("First", new SampleVO(111, "그루트", "주니어"));
		
		return map;
	}
	
	//데이터와 함계 HTTP 헤더 상태 메시지 등을 같이 전달하는 용도로 상욯나다.
	@GetMapping(value = "/check", params = {"height", "weight"})
	public ResponseEntity<SampleVO> check(Double height, Double weight){
		SampleVO vo = new SampleVO(0, ""+height, "" + weight);
		
		ResponseEntity<SampleVO> result = null;
		
		//150보다 작다면 502(오류) 코드와 데이터를 전송한다.
		if(height < 150) {
			result = ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(vo);
		} else {
			result = ResponseEntity.status(HttpStatus.OK).body(vo);
		}	
		return result;
	}
	
	//domain에 Ticket.java를 생성해 주었고 
	@PostMapping("/ticket")
	public Ticket convert(@RequestBody Ticket ticket) {
		log.info("convert............ticket" + ticket);
		
		return ticket;
	}
}
