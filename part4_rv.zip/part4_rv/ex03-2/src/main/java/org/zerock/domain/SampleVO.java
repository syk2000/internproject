package org.zerock.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
//객체 반환
public class SampleVO {
	
	private Integer mno;
	private String fistName;
	private String lastName;
}
