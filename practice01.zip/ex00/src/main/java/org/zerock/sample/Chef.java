package org.zerock.sample;

import org.springframework.stereotype.Component;
import lombok.Data;//pom.xml에서 사용한 lombok를 사용해 준다.

@Component
@Data
public class Chef {
	
}


