package org.zerock.persistence;

import java.sql.DriverManager;

import static org.junit.Assert.fail; //fail(e.getMessage());과 관련이 있다.

import java.sql.Connection; //Connection con오류 해결하기 위해 사용을 한다.

import java.sql.DriverManager;

import org.junit.Test;

import lombok.extern.log4j.Log4j;


//jdbc 제대로 들어 갔는지 구동 체크하기
@Log4j
public class JDBCTests {
	static {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testConnection() {
		
		try(Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE",
				"book_ex",
				"book_ex")) {
			log.info(con);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
}
