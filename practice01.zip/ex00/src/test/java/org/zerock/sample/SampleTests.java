package org.zerock.sample;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;//스프링을 실행하는 역할을 임시로 맡게 하여 설정을 하여 주었다. 가장 중요한 설정이다.
import org.springframework.beans.factory.annotation.Autowired;//

//root-context.xml의 경로를 자동으로 지정하여 사용을 할 수가 있다.
import org.springframework.test.context.ContextConfiguration;
//@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")와 관련이 되어 있다.

import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//@RunWith(SpringJUnit4ClassRunner.class)와 관련되어 있다.

import lombok.Setter;
import lombok.extern.log4j.Log4j;

//어떻게 구동을 하는지 알려주게 하는 코드를 할 것이다.
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j//log4j를 불러와 주어 log의 변수를 선언해 준 격이다.
public class SampleTests {
	
	@Setter(onMethod_ = {@Autowired})// 자동으로 주입해 달라는 것이다.
	private Restaurant restaurant;
	
	@Test
	public void testExist() {
		assertNotNull(restaurant);
		//log.의 오류가 다 사라지는 것을 확인 할 수가 있다.
		log.info(restaurant);
		log.info("--------------------------");
		log.info(restaurant.getChef());
	}
}
