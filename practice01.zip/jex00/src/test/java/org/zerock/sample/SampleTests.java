package org.zerock.sample;

import org.zerock.config.ContextConfiguration;
import org.zerock.config.Log4j;
import org.zerock.config.RootConfig;
import org.zerock.config.RunWith;
import org.zerock.config.SpringJUnit4classRunner;

@RunWith(SpringJUnit4classRunner.class)
@ContextConfiguration(classes= {RootConfig.class})
@Log4j
public class SampleTests {

}
