package org.zerock.mapper;

import org.apache.ibatis.annotations.Select;

public interface TimeMapper {
	//myBatis의 어노테이션을 이용해서 sql을 메서드에 추가한다.
	
	@Select("SELECT sysdate FROM dual")
	public String getTime();
	
	public String getTime2();
}
