package org.zerock.sample;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
//개발자가 직접 작성한 class를 Bean으로 등록하기 위한 어노테이션입니다
//주로 Bean과 비교가 많이 됨으로 비교해서 알아 놓으면 좋을 것 같습니다.

@Data 
// @ToString, @EqualsAndHashCode, @Getter, @Setter, @RequiredArgsConstructor을 한번에 사용하기 때문에 지양하도록 한다.
//문제가 생기면 큰일 날 수 있기 때문이다. 하지만 Restaurant에 사용할 것은 Lombok의 setter와 toString등을 자동으로 할 것입니다.
public class Chef {

}
