package org.zerock.sample;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.Setter;

@Component
@Data
public class Restaurant {

	@Setter(onMethod_ = @Autowired)
	private Chef chef; //데이터 값을 받아서 작성을 하겠다.
	
	//Chef와 restaurant개념은 의존성 주입에 관한 xml관련 예제 임으로 참고하면 될 것 같습니다.
}
