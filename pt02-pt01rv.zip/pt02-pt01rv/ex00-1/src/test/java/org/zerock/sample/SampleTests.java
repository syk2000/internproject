package org.zerock.sample;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)//스프링을 실행하는 역할임을 알리는 기능입니다.
@ContextConfiguration("file:srcfile:src/main/webapp/WEB-INF/spring/root-context.xml") //xml 파일을 불러와 실행을 잘 시킬 수 있게 해주었습니다.
@Log4j//출력을 쉽게 하기 위해 불러와 준 것입니다.
public class SampleTests {
	@Setter(onMethod_ = {@Autowired})//변수를 자동으로 주입하여 주세요 스프링의 장점을 극대화 하였다고 볼 수 있다.
	private Restaurant restaurant;
	
	@Test //junit에서 테스트기능을 실행시킬수 있습니다. 즉 테스트 작업이라고 보면 될 것 같습니다.
	public void testExist() {
		assertNotNull(restaurant);//이코드도 import값을 넣어주어야 에러가 나지 않는다
		
		log.info(restaurant);
		log.info("------------------------------------------");
		log.info(restaurant.getChef());
		
	}
}
