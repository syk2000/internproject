package org.zerock.mapper;

import java.util.List;

//import org.apache.ibatis.annotations.Select; @select와 관련 있는 import이다.
import org.zerock.domain.BoardVO;

public interface BoardMapper {
	
	//@Select("select * from tbl_board where bno > 0") BoardMapper.xml로 대체하여 필요가 없어져서 주석 처리를 하였다. 파일이 많을 때 불편하기 때문이다. 
	public List<BoardVO> getList();
	
	//insert 구문 추가해서 삽입하기
	public void insert(BoardVO board);
	
	public void insertSelectkey(BoardVO board);
		
	public void insertSelectKey(BoardVO board);
		
	public BoardVO read(Long bno);

	public int delete(long bno);
	
	public int update(BoardVO board);
	

}
