package org.zerock.persistence;
//이 패키지들은 나중에 추가를 ex00에 했던 패키지이며 또한 src/main/resource에 log4jdbc.log4j2.properties를 이용해 주었다.  db와 연동할때 필요한 것들이다.

import static org.junit.Assert.fail;

import java.sql.Connection;

import javax.sql.DataSource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:srfile:src/main/webapp/WEB-INF/spring/root-context.xml")

//자바 설정을 사용하는 경우
//@ContextConfiguration(classes={RootConfig.class})

@Log4j
public class DataSourceTests {
	
	@Setter(onMethod_ = {@Autowired})
	private DataSourceTests dataSource;
	
	@Test
	public void testConnection() {
		
		try(Connection con = ((DataSource) dataSource).getConnection()){
			log.info(con);
		}catch (Exception e) {
			// TODO: handle exception
			fail(e.getMessage());
		}
	}

}
